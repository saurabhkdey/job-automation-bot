from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
import time

def auto_apply(job, profile, credentials):
    try:
        options = Options()
        options.add_argument("--headless")
        driver = webdriver.Chrome(options=options)

        if job["platform"] == "indeed":
            driver.get(job["url"])
            time.sleep(3)
            # Simulate click on 'Apply Now', fill form fields, upload resume
            time.sleep(2)

        driver.quit()
        return True
    except Exception as e:
        print(f"Error applying to {job['title']}: {e}")
        return False
