import csv
from datetime import datetime

def log_application(job, success):
    with open("application_log.csv", "a", newline='') as f:
        writer = csv.writer(f)
        writer.writerow([datetime.now(), job["platform"], job["title"], job["url"], "Success" if success else "Failed"])
