import yaml
import json
from matcher.matcher import match_jobs
from scraper import indeed
from applier.apply_bot import auto_apply
from logger import log_application

with open("config/profile.yaml", "r") as f:
    profile = yaml.safe_load(f)

with open("config/credentials.json", "r") as f:
    credentials = json.load(f)

jobs = []
jobs += indeed.scrape_jobs(profile)

matched_jobs = match_jobs(jobs, profile)

for job in matched_jobs:
    success = auto_apply(job, profile, credentials)
    log_application(job, success)
