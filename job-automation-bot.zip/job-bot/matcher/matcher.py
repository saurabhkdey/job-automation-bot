def match_jobs(jobs, profile):
    matched = []
    keywords = set([k.lower() for k in profile["skills"]])
    for job in jobs:
        job_text = (job["title"] + " " + job["description"]).lower()
        score = sum(1 for kw in keywords if kw in job_text)
        if score >= 3:
            matched.append(job)
    return matched
