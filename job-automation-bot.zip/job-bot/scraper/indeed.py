import requests
from bs4 import BeautifulSoup

def scrape_jobs(profile):
    jobs = []
    url = "https://www.indeed.com/jobs?q=" + "+".join(profile['skills']) + "&l=" + profile['location'].replace(" ", "+")
    headers = {"User-Agent": "Mozilla/5.0"}

    res = requests.get(url, headers=headers)
    soup = BeautifulSoup(res.text, "lxml")

    for div in soup.find_all(name="div", attrs={"class":"job_seen_beacon"}):
        title = div.find("h2").text.strip()
        link = "https://www.indeed.com" + div.find("a")["href"]
        summary = div.find("div", class_="job-snippet").text.strip()
        jobs.append({
            "platform": "indeed",
            "title": title,
            "url": link,
            "description": summary
        })
    return jobs
